# Retail Sales Analysis via PostgreSQL & Tableau

## Project Overview
This project analyzes a retail sales dataset across multiple stores using PostgreSQL for cleaning and validation purposes; Tableau is used for dashboard visualization.

## Dataset Summary
This dataset contains daily sales records across multiple stores and products of the following:
-Sales and inventory activity
-Pricing, and discount information
-product category
-epidemic, and promotion status
-seasonality and weather conditions

## Project Workflow
1. Created a raw landing table in PostgreSQL with all columns imported as text
2. Created a cleaned table with corrected data types
3. Performed validation checks on:
   - categorical consistency
   - NULL and negative values
   - duplicate grain
   - store/category continuity
   - date/season consistency
   - reasonableness checks
4. Wrote SQL analysis queries for key business questions
5. Built Tableau dashboards from the analyzed outputs

## Data Validation Highlights
Validation checks confirmed that the cleaned dataset was acceptable for analysis. Key checks included:
- no unexpected NULL values
- no negative values in numeric business fields
- consistent mapping between store and region
- consistent category assignment at the store/product level
- no duplicate rows at the expected grain
- season values aligned with date values

## Business Questions Explored
- How does sales revenue change over time?
- Which product categories generate the most revenue?
- Which stores generate the most revenue?
- How does promotion status affect gross sales, average sales, and discount rate?
- How does epidemic status relate to sales revenue?
- How does seasonality affect total sales?

## Dashboard Structure

### Dashboard 1: Sales Overview
Focuses on high-level business performance and segmentation:
- Sale Revenue Over Time
- Sale Revenue by Category
- Sales Revenue by Store

### Dashboard 2: Sales Drivers and Context
Focuses on explanatory and contextual variables:
- Gross Sales by Promotion Status
- Avg Sales by Promotion Status
- Avg Discount Rate by Promotion Status
- Sale Revenue by Epidemic
- Total Sales by Season

## Future Enhancements
This dataset could support additional business questions beyond the scope of the current project, including:

- Which stores show the strongest or weakest sales trends over time?
- Which product categories are most sensitive to promotions or discounting?
- How does competitor pricing appear to influence sales performance?
- Are some stores more resilient than others during epidemic periods?
- Which seasons drive the strongest category-level sales performance?
- How do weather conditions affect product demand across stores or categories?
- Are certain store and category combinations consistently outperforming others?
- Does inventory level appear to align with demand patterns across time?
- Which stores may be overstocking or understocking relative to sales activity?
- How do discount levels vary by category, season, or store, and does that translate into stronger revenue performance?
